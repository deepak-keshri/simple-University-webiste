-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 30, 2021 at 06:06 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stud_data`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `email`, `password`) VALUES
(2, 'deepak@gmail.com', '498b5924adc469aa7b660f457e0fc7e5'),
(3, 'deepakeshari6387@gmail.com', '08eb625a1e00885e32155f76b8d50a89'),
(4, 'shiv@gmail.com', '2f8dd83a23b9ab0601e134123e9a0d9b'),
(5, 'satyam@gmail.com', '0f2cdafc6b1adf94892b17f355bd9110'),
(6, 'golu@gmail.com', '3fea0cdd9f8c9c37570f52918c70d067');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `name`, `mobile`, `email`, `password`) VALUES
(1, 'Deepak Keshri', '6387927467', 'deepak@gmail.com', '498b5924adc469aa7b660f457e0fc7e5'),
(2, 'deepak', '7777777777', 'uno@gmail.com', '498b5924adc469aa7b660f457e0fc7e5'),
(3, 'Deepak Keshri', '06387927467', 'deepu@gmail.com', 'ee49d65319f42e5e594c24832d81961b'),
(4, 'sumit', '6666666666', 'sumit@gmail.com', '7225ff71e8821b24fd72b4c8fda95b9a'),
(5, 'Deepak Keshri', '06387927467', 'golu1@gmail.com', '3fea0cdd9f8c9c37570f52918c70d067'),
(6, 'Deepak Keshri', '06387927467', 'mahi@gmail.com', '99941a8015cd830b498cd9f0ddf4a500');

-- --------------------------------------------------------

--
-- Table structure for table `stud_rec`
--

CREATE TABLE `stud_rec` (
  `id` int(11) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `father_name` varchar(30) NOT NULL,
  `mother_name` varchar(30) NOT NULL,
  `course` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `adhar` varchar(15) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `religion` varchar(20) NOT NULL,
  `nationality` varchar(20) NOT NULL,
  `address` varchar(200) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stud_rec`
--

INSERT INTO `stud_rec` (`id`, `first_name`, `last_name`, `user_name`, `father_name`, `mother_name`, `course`, `dob`, `gender`, `adhar`, `mobile`, `religion`, `nationality`, `address`, `pincode`, `password`) VALUES
(16, 'Rahul', 'kumar', 'rahul', 'Surendra', 'Suneeta', 'B-tech', '1999-02-23', 'male', '123456789098', '2323232323', 'Hindu', 'Indian', 'Prayagraj', '233212', 'd41d8cd98f00b204e9800998ecf8427e'),
(17, 'Satyam', 'Kumar', 'satyam', 'Avadesh mishra', 'Sunita', 'BCA', '1901-07-10', 'male', '999999999999', '8765432123', 'Hindu', 'Indian', 'Kitganj prayagraj', '231214', '0f2cdafc6b1adf94892b17f355bd9110'),
(18, 'Pradeep', 'Prajapati', 'pradeep', 'Shivank', 'Shivani', 'MA', '2002-02-10', 'male', '950687653428', '06387927467', 'Hindu', 'Indian', 'Brham nagar', '333333', '2467d3744600858cc9026d5ac6005305'),
(19, 'Deepak', 'Keshri', 'deepak', 'Rajesh', 'Meena Devi', 'BCA', '2000-07-10', 'male', '950634657898', '06387927467', 'Hindu', 'Indian', 'Brham nagar', '231216', '827ccb0eea8a706c4c34a16891f84e7b'),
(20, 'Samir', 'Singh', 'samir', 'Rahul ', 'Yashi', 'MCA', '2000-05-20', 'male', '888888888888', '8976542378', 'Hindu', 'Indian', 'Prayagraj', '231217', '498b5924adc469aa7b660f457e0fc7e5'),
(21, 'Yashi', 'Srivastva', 'yashu', 'Raju', 'Reena', 'BCA', '2005-11-11', 'female', '787878787878', '7676767676', 'Hindu', 'Indian', 'Kanpur', '444444', '09e868b2c6c346df8251f22d957c3a54'),
(22, 'Mahedra', 'kumar', 'mahi', 'Kushendra', 'kanika', 'B-tech', '2003-02-06', 'male', '765456545676', '3546273866', 'Hindu', 'Indian', 'nagpur', '222222', '5bd2026f128662763c532f2f4b6f2476'),
(23, 'Sayesh', 'singh', 'sayesh', 'Samir', 'yashi', 'Bsc', '2021-12-23', 'male', '123456789987', '9898989898', 'hindi', 'india', 'prayag raj', '342522', '21b77a6be73e5d35d9154e0ef89ab1f5'),
(24, 'Shreyansh', 'Kumar', 'shrey', 'Sarvesh', 'Anamika', 'M-tech', '1999-03-31', 'male', '777766665555', '6576879876', 'Hindu', 'Indian', 'Sonbhadra', '233445', '88864c3c6137968735bb0dc2c6d3dd01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stud_rec`
--
ALTER TABLE `stud_rec`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `stud_rec`
--
ALTER TABLE `stud_rec`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
