<?php include 'header.php'; ?>
<div class="slider-container" >
  <img class="mySlides" src="image/uni1.jpg" height="520" width="100%"/>
  <img class="mySlides" src="image/uni2.jpg" height="520" width="100%"/>
  <img class="mySlides" src="image/uni3.jpg" height="520" width="100%"/>
  <img class="mySlides" src="image/uni4.jpg" height="520" width="100%"/>
  <img class="mySlides" src="image/uni5.jpg" height="520" width="100%"/>
  <img class="mySlides" src="image/comp.jpg" height="520" width="100%"/>
  <!-- <img class="mySlides" src="image/uni3.jpg" height="500" width="1000"/> -->
</div>
<hr>
<hr>
<script>
var myIndex = 0;
ImgSlide();

function ImgSlide() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1} 
  x[myIndex-1].style.display = "block";
  // x[myIndex-1].transitionPproperty="display";
  // x[myIndex-1].style.transitionduration="0.5s";
  
  setTimeout(ImgSlide, 2000); // Change image every 2 seconds
}
</script>

<div id="professor">
  <div id="professor-div">
    <div id="professor-img-div">
      <a href="professor.php">
        <img src="image/professor.jpg" id="professor-img" height="450" width="800">
      </a>
    </div>
    <div id="convocation">CONVOCATION</div>
  </div>
</div>

<div id="visitor">
  <table>
    <tr>
      <td>
        <a href="president.php">
          <img src="image/ramnath.jpeg" height="300" width="265" class="visitor">
        </a>
        <div class="visitor-name">Shri Ram Nath Kovind</div>
        <div class="visitor-position">PRESIDENT OF INDIA</div>
      </td>

      <td>
        <a href="chief-m.php">
            <img src="image/yogi.jpg" height="300" width="265" class="visitor">
          </a>
          <div class="visitor-name">Shri Yogi Adiyanath</div>
          <div class="visitor-position">CHIEF MINISTER OF UP</div>
      </td>

      <td>
        <a href="education-m.php">
          <img src="image/dharamendra.jpeg" height="300" width="265" class="visitor">
        </a>
        <div class="visitor-name">Shri Dharamedra Pradhan</div>
        <div class="visitor-position">MINISTRY OF EDUCATION</div>
      </td>

      <td>
        <a href="professor.php">
          <img src="image/professor.jpg" height="300" width="265" class="visitor">
        </a>
        <div class="visitor-name">Prof. Pradeep Prajapati</div>
        <div class="visitor-position">VICE-CHANCELLOR OF SU</div>
      </td>
    </tr>
  </table>
</div>
<?php include 'footer.php'; ?>