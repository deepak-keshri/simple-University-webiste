<?php include 'header.php'; ?>
<div id="contact">Contact to University</div>

<div id="container">
  <div id="contact-info">
    <div id="address">
      <img src="image/address.png" height="40" width="40">
      <h2>ADDRESS</h2>
      <h3>Senate House Campus, Churk Road, Sonbhadra, Uttar Pradesh - 231216</h3>
    </div>

    <div id="phone">
      <img src="image/phone.png" height="40" width="40">
      <h2>PHONE</h2>
      <h3>6387927467</h3>
    </div>
    

  </div>
  <div id="contact-massage">

    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
      <table>
        <tr>
          <td>
            <input type="text" name="fname" placeholder="First Name" required class="contact-name">
            <input type="text" name="fname" placeholder="Last Name" required class="contact-name">
          
            <select name="gender" id="" required class="contact-name">
              <option value="" disabled selected>Select Gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
            </select>
          </td>
        </tr>

        </tr>
          <td>
            <input type="email" name="email" placeholder="Email" required class="contact-info">
            <input type="number" name="phone" placeholder="Phone Number" min="1000000000" max="9999999999" required class="contact-info">
          </td>
        <tr>
          <td><textarea name="massage" placeholder="Massage" required class="contact-massage" ></textarea></td>
        </tr>
        <tr>
          <td><input type="submit" value="Submit" name="submit" class="update"></td>
        </tr>
      </table>
    </form>
  </div>
</div>

