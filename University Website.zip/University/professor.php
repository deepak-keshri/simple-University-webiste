<?php
  include 'header.php';
?>
<div id="about-us">Message from Hon'ble Vice Chancellor</div>
<div id="pro">
  <img src="image/professor.jpg" height="350" width="300">
  <div>
    <h2>Dear Colleagues & Students,</h2>

    My greetings and congratulations to all of you on the Foundation Day.

    It is a matter of great pride that our institution is celebrating its 134th Foundation Day. After all these years have gone by in the history of the institution, I take great pride in being the first man Vice-Chancellor of my alma meter. I thank all of you for rendering me all the support viz.-a-viz. meeting online classes, working on committees and organizing other events required to run the institution. With a very discerning eye I feel a lot of gratitude in saying that I have found the entire institution has come together as a big team to work and extend all possible cooperation to me।

    It is my dream and desire to see this institution among the leading institution in academics, sports, cultural pursuits, innovation, patents, etc. It is heart warming to see the love and support that I get from all of you. When all of us are in, I am sure we shall be able to find a way out to realize our dream for our institution.

    As we emerge out of the Covid situation, I am trying to reopen the University in a phased manner. All PG Semester II & IV class reopen for physical teaching from 1 st October, 2021 in a first phase. In the second phase if all is right, we shall further open offline teaching for more classes. I have been getting a feed back that the online classes were being conducted regularly despite the calamity and exams were conducted and results declared meticulously.

    My congratulations once again.
  </div>
</div>
<hr>
<?php include 'footer.php'; ?>