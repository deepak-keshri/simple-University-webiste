<?php
/*   session_start();
  if(!isset($_SESSION["email"])){
    header("Location: http://localhost/PHP/University/admin/login.php");
  }
  else{
    include 'header.php';
  } */
  include "header.php";
    
?>
<div id="all-rec"> 
  <table border="1">
    <tr class="row" id="row-id">
      <td>S.No.</td>
      <td>FULL NAME</td>
      <td>USERNAME</td>
      <td>COURSE</td>
      <td>DOB</td>
      <td>GENDER</td>
      <td>MOBILE No.</td>
      <td>VIEW</td>
      <td>UPDATE</td>
      <td>DELETE</td>
    </tr>

    <?php
      include 'config.php';
      $sql = "SELECT *FROM stud_rec";
      $res = mysqli_query($conn,$sql);
      
      if (mysqli_num_rows($res))
      {
        while ($row = mysqli_fetch_assoc($res))
        {
    ?>
    <tr class="row">
      <td><?php echo $row['id']; ?></td>
      <td><?php echo $row['first_name']." ".$row['last_name']; ?></td>
      <td><?php echo $row['user_name']; ?></td>
      <td><?php echo $row['course']; ?></td>
      <td><?php echo $row['dob']; ?></td>
      <td><?php echo $row['gender']; ?></td>
      <td><?php echo $row['mobile']; ?></td>
      <td><a href="view.php?id=<?php echo $row['id']; ?>" class="view">View</a></td>
      <td><a href="update-link.php?id=<?php echo $row['id']; ?>" class="update">Update</a></td>
      <td><a href="delete-link.php?id=<?php echo $row['id']; ?>" class="delete">Delete</a></td>
    </tr>
    <?php }} ?>
  </table>
</div>
<?php