<?php
  include 'header.php';
?>
<div id='login-id'>
  <div id='login'>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
      <table>
        <tr>
          <td>
            <h1>Add Admin</h1>
          </td>
        </tr>

        <tr>
          <td><input type="email" name="new_admin" placeholder="New admin email" class="style" required></td>
        </tr>

        <tr>
          <td><input type="password" name="new_password" placeholder="Password" class="style" required></td>
        </tr>

        <tr>
          <td><input type="password" name="main_password" placeholder="Main admin Password" class="style" required></td>
        </tr>

        <tr>
          <td><input type="submit" value="Admin" name="Admin" class="login"></td>
        </tr>
      </table>
    </form>
    <?php
      if (isset($_REQUEST['Admin'])){
        include 'config.php';
    
        $main_password = md5($_POST['main_password']);
        $email=mysqli_real_escape_string($conn,$_POST['new_admin']);
        
        $sql1 = "SELECT *FROM admin WHERE email='{$email}'";
        $res1 = mysqli_query($conn,$sql1) or die("Query Failed");
        if(mysqli_num_rows($res1)>=1) 
        {
          while($row = mysqli_fetch_assoc($res1))
          {
            if($email == $row['email'])
            echo "<div id='warn'>This email id is already exists</div>";
          }
        }                
        else
        {
          $sql = "SELECT *FROM admin WHERE email='deepak@gmail.com' AND password='{$main_password}'";
          $res = mysqli_query($conn,$sql) or die("Query Failed");
  
          if (mysqli_num_rows($res)>=1)
          {
            $password=md5($_POST['new_password']);
      
            $sql="INSERT INTO admin(email, password) VALUES('{$email}','{$password}')";
            mysqli_query($conn,$sql) or die("Query Failed");
            header("Location: http://localhost/PHP/University/admin/all-record.php");
          }
          else
          echo "<div id='warn'>Incorrect Password</div>";
        }        
      }
    ?>
  </div>
</div>