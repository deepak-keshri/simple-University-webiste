<?php
  $conn = mysqli_connect("localhost","root","","stud_data") or die("Connection Failed");
?>