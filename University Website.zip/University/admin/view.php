<?php 
  include 'header.php';
  include 'config.php';
  $id = $_GET['id'];
  $sql = "SELECT *FROM stud_rec WHERE id={$id}";
  $res = mysqli_query($conn,$sql) or die("Query Failed");
  if (mysqli_num_rows($res)){
    while ($row = mysqli_fetch_assoc($res)){
?>
<div id="view-data">
  <div id="view" class="add">
      <table id="add-table" border="1">
        <tr>
          <td colspan="2" style="text-align:center; color: yellow; background: rgb(2, 2, 207);"><h1>VIEW<h2></td>
        </tr>
        
        <tr>
          <td>First Name</td>
          <td>
            <input type="text" value="<?php echo $row['first_name']; ?>" name="fname" placeholder="first name" class="input-odd" readonly>
          </td>
        </tr>

        <tr>
          <td>Last Name</td>
          <td><input type="text" value="<?php echo $row['last_name']; ?>" name="lname" placeholder="last name" class="input-even"  readonly></td>
        </tr>

        <tr>
          <td>User Name</td>
          <td><input type="text" value="<?php echo $row['user_name']; ?>" name="user_name" placeholder="user name" class="input-odd" readonly></td>
        </tr>

        <tr>
          <td>Father Name</td>
          <td><input type="text" value="<?php echo $row['father_name']; ?>"name="father_name" placeholder="father name" class="input-even" readonly></td>
        </tr>

        <tr>
          <td>Mother Name</td>
          <td><input type="text" value="<?php echo $row['mother_name']; ?>" name="mother_name" placeholder="mother name" class="input-odd" readonly></td>
        </tr>

        <tr>
          <td>Course</td>
          <td  class="input-even"><?php echo $row['course']; ?></td>
        </tr>

        <tr>
          <td>Date of Birth</td>
          <td><input type="date" value="<?php echo $row['dob']; ?>" name="dob"  class="input-odd" readonly></td>
        </tr>

        <tr>
          <td>Gender</td>
          <td  class="input-even"><?php echo $row['gender']; ?></td>
        </tr>

        <tr>
          <td>Adhar Number</td>
          <td><input type="number" value="<?php echo $row['adhar']; ?>" name="adhar" placeholder="Adhar Number" min="100000000000" max="999999999999" class="input-odd" readonly></td>
        </tr>

        <tr>
          <td>Mobile Number</td>
          <td><input type="number" value="<?php echo $row['mobile']; ?>" name="mobile" placeholder="Adhar Number" min="1000000000" max="9999999999" class="input-even" readonly></td>
        </tr>

        <tr>
          <td>Religion</td>
          <td><input type="text" value="<?php echo $row['religion']; ?>" name="religion" placeholder="religion Number" class="input-odd" readonly></td>
        </tr>

        <tr>
          <td>Nationality</td>
          <td><input type="text" value="<?php echo $row['nationality']; ?>" name="nationality" placeholder="Nationality" class="input-even" readonly></td>
        </tr>

        <tr>
          <td>Address</td>
          <td><input type="text" value="<?php echo $row['address']; ?>" name="address" placeholder="address" class="input-odd" readonly></td>
        </tr>

        <tr>
          <td>Pin code</td>
          <td><input type="number" value="<?php echo $row['pincode']; ?>" name="pincode" placeholder="pin code" min="100000" min="999999" class="input-even" readonly></td>
        </tr>
      </table>
  </div>
</div>
<?php }} 
  include 'footer.php';
?>