<?php include 'header.php' ?>
<div id="update-add">
  <div class="add" >
    <div id="id-search">
      <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
        <strong>ID</strong>
        <input type="number" name="id" placeholder="Search ID" min="1" required>
        <input type="submit" value="Search" id="search" name="search">
      </form>
    </div>

    <?php 
      if (isset($_REQUEST['search']))
      {
        include 'config.php';
        $id = $_POST['id'];
        $sql = "SELECT *FROM stud_rec WHERE id={$id}";
        $res = mysqli_query($conn,$sql) or die("Query Failed");
        if (mysqli_num_rows($res)){
          while ($row = mysqli_fetch_assoc($res)){
      
    ?>

    <form action="update-link-query.php" method="post">
   <table id="add-table">
        <tr>
          <td colspan="2" style="text-align:center; color: white; background: green; border-radius: 10px;"><h1>UPDATE<h2></td>
        </tr>
        <tr>
          <td>First Name</td>
          <td>
            <input type="text" value="<?php echo $row['first_name']; ?>" name="fname" placeholder="first name" required>
            <input type="hidden" value="<?php echo $row['id']; ?>" name="id">
          </td>
        </tr> 

        <tr>
          <td>Last Name</td>
          <td><input type="text" value="<?php echo $row['last_name']; ?>" name="lname" placeholder="last name" required></td>
        </tr>

        <tr>
          <td>User Name</td>
          <td><input type="text" value="<?php echo $row['user_name']; ?>" name="user_name" placeholder="user name" required></td>
        </tr>

        <tr>
          <td>Father Name</td>
          <td><input type="text" value="<?php echo $row['father_name']; ?>"name="father_name" placeholder="father name" required></td>
        </tr>

        <tr>
          <td>Mother Name</td>
          <td><input type="text" value="<?php echo $row['mother_name']; ?>" name="mother_name" placeholder="mother name" required></td>
        </tr>

        <tr>
          <td>Course</td>
          <td>
            <select name="course" id="course" value="" >
              <option disabled>Select Course</option>
              <option value="BA"<?php if($row['course']=="BA") echo 'selected = selected';?>>BA</option>
              <option value="BCA" <?php if($row['course']=="BCA") echo 'selected = selected';?>>BCA</option>
              <option value="Bsc" <?php if($row['course']=="Bsc") echo 'selected = selected';?>>Bsc</option>
              <option value="B-tech" <?php if($row['course']=="B-tech") echo 'selected = selected';?>>B-tech</option>
              <option value="MA" <?php if($row['course']=="BCA") echo 'selected = selected';?>>MA</option>
              <option value="MCA" <?php if($row['course']=="MCA") echo 'selected = selected';?>>MCA</option>
              <option value="Msc" <?php if($row['course']=="Msc") echo 'selected = selected';?>>Msc</option>
              <option value="M-tech" <?php if($row['course']=="M-tech") echo 'selected = selected';?>>M-tech</option>
            </select>  
        </tr>

        <tr>
          <td>Date of Birth</td>
          <td><input type="date" value="<?php echo $row['dob']; ?>" name="dob"  required></td>
        </tr>

        <tr>
          <td>Gender</td>
          <?php 

            echo '<td id="Gender">';
            $gen = $row['gender'];
            if ($gen == "male")
            {
              echo '<input type="radio" value="male" name="gender" checked>Male';
              echo '<input type="radio" value="female" name="gender">Female';
              echo '<input type="radio" value="other" name="gender" >Other';
            } else if ($gen == "female")
            {
              echo '<input type="radio" value="male" name="gender" >Male';
              echo '<input type="radio" value="female" name="gender" checked>Female';
              echo '<input type="radio" value="other" name="gender" >Other';
            }else
            {
              echo '<input type="radio" value="male" name="gender" >Male';
              echo '<input type="radio" value="female" name="gender">Female';
              echo '<input type="radio" value="other" name="gender" checked>Other';
            }

            echo "</td>";
          ?>
          
        </tr>

        <tr>
          <td>Adhar Number</td>
          <td><input type="number" value="<?php echo $row['adhar']; ?>" name="adhar" placeholder="Adhar Number" min="100000000000" max="999999999999" required></td>
        </tr>

        <tr>
          <td>Mobile Number</td>
          <td><input type="number" value="<?php echo $row['mobile']; ?>" name="mobile" placeholder="Adhar Number" min="1000000000" max="9999999999" required></td>
        </tr>

        <tr>
          <td>Religion</td>
          <td><input type="text" value="<?php echo $row['religion']; ?>" name="religion" placeholder="religion Number" required></td>
        </tr>

        <tr>
          <td>Nationality</td>
          <td><input type="text" value="<?php echo $row['nationality']; ?>" name="nationality" placeholder="Nationality" required></td>
        </tr>

        <tr>
          <td>Address</td>
          <td><input type="text" value="<?php echo $row['address']; ?>" name="address" placeholder="address" required></td>
        </tr>

        <tr>
          <td>Pin code</td>
          <td><input type="number" value="<?php echo $row['pincode']; ?>" name="pincode" placeholder="pin code" min="100000" min="999999" required></td>
        </tr>

        <tr style="text-align: center; ">
          <td colspan="2">
            <input type="submit" value="Save" style=" cursor: pointer; width: 120px;">
          </td>
        </tr>
      </table>

    </form>
  </div>
</div>
<?php 
      }
    }
    else
    {
      echo "<div id='warn'>Invailid ID</div>";
    }
  }
  
?>
