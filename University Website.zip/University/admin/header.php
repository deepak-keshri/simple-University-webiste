<?php
  include 'config.php'; 
  session_start();

  if (!isset($_SESSION["email"])){
    header("Location: http://localhost/PHP/University/admin/");
  }
?>
<html>
  <head>
    <title>University</title>  
    <link rel="stylesheet" href="../style/style.css" />
  </head>
  <body>
    <div id="header">
      <img src='../image/university.png' height="100" width="100"/>
      <a href="all-record.php" id="home">Sonbhadra University</a>
      <a href="logout.php" id='login-link'>Log out</a>
    </div>
    <div id="menu-bar">
        <ul>
          <li><a href="add.php">ADD</a></li>
          <li><a href="update.php">UPDATE</a></li>
          <li><a href="delete.php">DELETE</a></li>
          <li><a href="all-record.php">All Record</a></li>
          <li><a href="add-admin.php">Add Admin</a></li>
        </ul>
    </div>