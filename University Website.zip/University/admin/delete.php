<?php 
  include 'header.php';      
?>
<div class="id-delete">
  <div id="id-search">
    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
      <strong>ID</strong>
      <input type="number" name="id" placeholder="Delete Record" min="1" required>
      <input type="submit" value="Delete" class="delete" name="delete">
    </form>
  </div>
</div>
<?php
  if (isset($_REQUEST['delete']))
  {
    include 'config.php';
    $id = $_POST['id'];
    $sql = "DELETE FROM stud_rec WHERE id={$id}";
    $res = mysqli_query($conn,$sql) or die("Query Failed");

    mysqli_close($conn);
  }
?>