<?php 
  include 'header.php';
?>
<div id="add">
  <div class="add">
    <form action="add-query.php" method="post">

      <table id="add-table">
        <tr>
          <td>First Name</td>
          <td><input type="text" name="fname" class="stylish" placeholder="First Name" required></td>
        </tr>

        <tr>
          <td>Last Name</td>
          <td><input type="text" name="lname" class="stylish" placeholder="Last Name" required></td>
        </tr>

        <tr>
          <td>User Name</td>
          <td><input type="text" name="user_name" class="stylish" placeholder="User Name" required></td>
        </tr>

        <tr>
          <td>Father Name</td>
          <td><input type="text" name="father_name" class="stylish" placeholder="Father Name" required></td>
        </tr>

        <tr>
          <td>Mother Name</td>
          <td><input type="text" name="mother_name" class="stylish" placeholder="Mother Name" required></td>
        </tr>

        <tr>
          <td>Course</td>
          <td>
            <select name="course" id="course" class="stylish" required>
              <option value="" disabled selected>Select Course</option>
              <option value="BA">BA</option>
              <option value="BCA">BCA</option>
              <option value="Bsc">Bsc</option>
              <option value="B-tech">B-tech</option>
              <option value="MA">MA</option>
              <option value="MCA">MCA</option>
              <option value="Msc">Msc</option>
              <option value="M-tech">M-tech</option>
            </select>  
        </tr>

        <tr>
          <td>Date of Birth</td>
          <td><input type="date" name="dob"  class="stylish" required></td>
        </tr>

        <tr>
          <td>Gender</td>
          <td id="Gender">
            <input type="radio" value="male" name="gender" required>Male
            <input type="radio" value="female" name="gender" required>Female
            <input type="radio" value="other" name="gender" required>Other
          </td>
        </tr>

        <tr>
          <td>Adhar Number</td>
          <td><input type="number" name="adhar" class="stylish" placeholder="Adhar Number" min="100000000000" max="999999999999" required></td>
        </tr>

        <tr>
          <td>Mobile Number</td>
          <td><input type="number" name="mobile" class="stylish" placeholder="Mobile Number" min="1000000000" max="9999999999" required></td>
        </tr>

        <tr>
          <td>Religion</td>
          <td><input type="text" name="religion" class="stylish" placeholder="Religion" required></td>
        </tr>

        <tr>
          <td>Nationality</td>
          <td><input type="text" name="nationality" class="stylish" placeholder="Nationality" required></td>
        </tr>

        <tr>
          <td>Address</td>
          <td><input type="text" name="address" class="stylish" placeholder="Address" required></td>
        </tr>

        <tr>
          <td>Pin code</td>
          <td><input type="number" name="pincode" class="stylish" placeholder="Pin code" min="100000" min="999999" required></td>
        </tr>

        <tr>
          <td>Password</td>
          <td><input type="password" name="password" class="stylish" placeholder="Password" required></td>
        </tr>

        <tr style="text-align: center; ">
          <td colspan="2">
            <input type="submit" value="Save" style=" cursor: pointer; width: 120px;">
          </td>
        </tr>
      </table>

    </form>
  </div>
</div>
<?php include 'footer.php'; ?>