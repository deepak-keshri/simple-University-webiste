<?php
  if(isset($_COOKIE['email']) && isset($_COOKIE['password']))
  {
    setcookie("email","",time()-60*60*24*10);
    setcookie("password","",time()-60*60*24*10);

    header("Location: http://localhost/PHP/University/home.php");
  }
?>