<?php 
  include 'header.php'; 
  
  if(isset($_COOKIE['email']) && isset($_COOKIE['password']))
  {
    header("Location: http://localhost/PHP/University/home.php");
  }
?>
<div id='login-id'>
  <div id='login'>
    <!-- <span id="close" onclick="Close()">x</span> -->
    <form action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
      <table>
        <tr>
          <td>
            <a href='index.php' class="button">Login</a>
            <!-- <a href='register.php' class="button">Register</a> -->
            <input type="button" class="button" value="Register">
          </td>
        </tr>

        <tr>
          <td><h1>Register</h1></td>
        </tr>

        <tr>
          <td><input type="text" name="name" placeholder="Enter name" class="style" required></td>
        </tr>

        <tr>
          <td><input type="number" name="mobile" min="1000000000" max="9999999999" placeholder="Mobile number" class="style" required></td>
        </tr>

        <tr>
          <td><input type="email" name="email" placeholder="Username or email" class="style" required></td>
        </tr>

        <?php
          if (isset($_REQUEST['register']))
          {
            include 'config.php';

            $name = mysqli_real_escape_string($conn,$_POST['name']);
            $mobile = mysqli_real_escape_string($conn,$_POST['mobile']);
            $email = mysqli_real_escape_string($conn,$_POST['email']);
            $password = md5($_POST['password']);

            $sql1 = "SELECT *FROM register WHERE email='{$email}'";
            $res = mysqli_query($conn,$sql1);
            if(mysqli_num_rows($res)>=1)
            {
              while($row = mysqli_fetch_assoc($res))
              {
                if($email == $row['email'])
                echo "<tr><td id='warn'>This email id is already exists</td></tr>";
              }
            }
            else
            {
          
              $sql = "INSERT INTO register(name, mobile, email, password) VALUES('{$name}','{$mobile}','{$email}','{$password}')";
              mysqli_query($conn,$sql);// or die("Query Failded");
            
              setcookie("email",$email,(time()+60*60*24*10));
              setcookie("password",$password,(time()+60*60*24*10));
              header("Location: http://localhost/PHP/University/home.php");
            }
          }
        ?>

        <tr>
          <td><input type="password" name="password" class="style" placeholder="Passsword" required></td>
        </tr>

        <tr>
          <td><input type="submit" name="register" value="Register" class="login"></td>
        </tr>
      </table>
    </form>
  </div>
</div>