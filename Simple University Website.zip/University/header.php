<html>
  <head>
    <title>University</title>  
    <link rel="stylesheet" href="style/style.css" />
  </head>
  <body>
    <div id="header">
      <img src='image/university.png' height="100" width="100"/>
      <a href="home.php" id="home">Sonbhadra University</a>
      <?php if(isset($_COOKIE['email']) && isset($_COOKIE['password'])){ ?>
      <a href="logout.php" name="login-btn" id='login-link'>Log out</a>
      <?php }else{ ?>
      <a href="index.php" name="login-btn" id='login-link'>Log in</a>
      <?php } ?>
      <!-- <input type="submit" onClick="Focus()" name="login-btn" id='login-link' value="Log in"> -->
      </form>
    </div>
    <hr>
    <div id="menu-bar">
        <ul>
          <li><a href="home.php">Home</a></li>
          <!-- <li><a href="student.php">Student</a></li> -->
          <li><a href="about-us.php">About Us</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
    </div>
    <hr>