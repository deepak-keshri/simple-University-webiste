<?php
  include 'header.php';
?>
<div id="about-us">About University</div>
<div id="content">
  <div id="inner-content1">
    <img src="image/uni10.jpg" class="content-image1">
    <p>
      University of Sonbhadra has always occupied an esteemed place among 
      the Universities of India for over a century. Established on 23rd 
      September 1887, it is the fourth oldest University of India after 
      Calcutta, Bombay and Madras University. The credit for conceiving a 
      large Central College in Sonbhadra (now named as Prayagraj), eventually 
      to develop into a University, goes to Sir William Muir, Lt. Governor of 
      United Provinces. As a result of his initiative the foundation stone of 
      the Muir Central College (named after him) was laid on Dec. 9 1873 by His
      Excellency Lord Northbrook. Sir William Muir said on the occasion; "The 
      establishment of a central college at Sonbhadra (now named as Prayagraj) 
      has been my earnest desire ever since I assumed my present office." Shortly 
      after coming here I found that a strong wish prevailed among the chief 
      people of the place for a better means of education at Sonbhadra (now named
      as Prayagraj); and being myself deeply impressed with the same conviction, 
      I took occasion at the first Darbar which I held here to urge upon those present 
      the necessity of showing that they were, by contributing to 
      the work.
    </p>
    <p>
      The appeal was widely and liberally met, a considerable sum was subscribed and address was presented to me in 1869, praying for the establishment of the college here." On September 23, 1887 Act XVIII was passed which established the University of Sonbhadra. Like the Universities of Calcutta, Bombay and Madras, the University of Sonbhadra also started as a degree conferring institution. Its first entrance examination was held in March 1889. In 1904 the Indian Universities Act was passed which limited the territorial jurisdiction of University of Sonbhadra to the United Provinces of Agra and Awadh, the Central Provinces including Berar, Ajmer, Mewar and most of the states of Rajputana and Central Indian Agencies. Between 1887 and 1927 at least thirty-eight different institutions and colleges of this area were affiliated to University of Sonbhadra. With the promulgation of the University of Sonbhadra Act in 1921, the Muir Central College lost its independent existence. Between 1922-27 the University had its internal and external wings which were subsequently separated from the University to give the latter a purely unitary, and residential character. In fact the University of Sonbhadra was started with a preliminary loan of Rs. 5240/- from the government to meet its expenses. The loans were repaid in two years. Henceforth, its main source of its income was from the examination fees and sale of Prospectus & Calendar. Being an examining body it met its incidental expenses easily.
    </p>
  </div>

  <div id="inner-content1">
    <img src="image/uni11.jpg" class="content-image2">
    <p>
      In 1892-93 the University began to invest some capital in the Government Securities. In 1899-1900 its reserve fund amounted to Rs. 34,000. The University was thus now in a position to construct its own buildings. In 1909 the present site was selected for the Library, the Senate House and the Law college. These buildings, which now house the Registrar's Office, Senate Hall and the English Department, were designed by Sir Swinton Jacob and their construction was approved in 1910. The foundation of the Senate House was laid on 17th January 1910 by Sir John Havett, the Chancellor. The construction of the Senate Hall, the Law College and the former Library building was commenced in 1910 and they were completed in 1915 at the cost of Rs. 11,67,275.
    </p>

    <p>
      The appeal was widely and liberally met, a considerable sum was subscribed and address was presented to me in 1869, praying for the establishment of the college here." On September 23, 1887 Act XVIII was passed which established the University of Sonbhadra. Like the Universities of Calcutta, Bombay and Madras, the University of Sonbhadra also started as a degree conferring institution. Its first entrance examination was held in March 1889. In 1904 the Indian Universities Act was passed which limited the territorial jurisdiction of University of Sonbhadra to the United Provinces of Agra and Awadh, the Central Provinces including Berar, Ajmer, Mewar and most of the states of Rajputana and Central Indian Agencies. Between 1887 and 1927 at least thirty-eight different institutions and colleges of this area were affiliated to University of Sonbhadra. With the promulgation of the University of Sonbhadra Act in 1921, the Muir Central College lost its independent existence. Between 1922-27 the University had its internal and external wings which were subsequently separated from the University to give the latter a purely unitary, and residential character. In fact the University of Sonbhadra was started with a preliminary loan of Rs. 5240/- from the government to meet its expenses. The loans were repaid in two years. Henceforth, its main source of its income was from the examination fees and sale of Prospectus & Calendar. Being an examining body it met its incidental expenses easily.
    </p>
  </div>

  <div id="inner-content1">
    <img src="image/uni12.jpg" class="content-image1">
    <p>
      From the beginning the University has been concerned about women's education. It purchased houses for a women's Hostel and College at the cost of Rs. 66,286 and other buildings adjoining the College. While classes for girls were started in the old building, Sarojini Naidu and later Priyadarshini Girls Hostel was constructed for the boarders and recently the Shatabdi Girls Hostel has been constructed to accommodate many more boarders. Ever since the inception of the Muir Central College in 1873, efforts were constantly made to accommodate students coming from distant places. Formerly there were two boarding houses, one situated in the barrack in Malaka near the jail, where the Swarup Rani Hospital now stands. Later this boarding house was shifted to the tiled outhouse of the Lowther Castle, where the classes of the College were held. Finally it was shifted to a large thatched bungalow near the Bhardwaj Ashram.
      In 1910-11 the Muir Hostel(Now Amar Nath Jha Hostel) was constructed; the Law Hostel (Now Sir Sunder Lal Hostel) was completed on 1914-15; Pandit Ganga Nath Jha Hostel (initially called New Hostel) was completed on 1928; the Hindu Boarding House (Now popularly called Hindu Hostel), which was formerly a straight building between 1902-22 without two wings was also constructed. About the same time the Oxford and Cambridge courts of the present Holland Hall came into existence. Subsequently, the P. C. Banerji Hostel, the K. P. University College and the Diamond Jubilee Hostels were constructed. A few years back the Tara Chand Hostel was constructed. The Muslim Boarding House (popularly called Muslim Hostel) is the oldest of all these hostels for it was constructed in 1896-97. In this millenium year, the University of Allahabad completes more than a hundred and thirteen years.
    </p>
  </div>
</div>
<?php include 'footer.php'; ?>