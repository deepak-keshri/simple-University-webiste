<?php 
  include 'header.php'; 
  
  if(isset($_COOKIE['email']) && isset($_COOKIE['password']))
  {
    header("Location: http://localhost/PHP/University/home.php");
  }
?>
<div id='login-id'>
  <div id='login'>
    <!-- <input type="button" id="close" onclick=""> -->    
    <!-- <span id="close" onclick="Close()">x</span> -->
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
      <table>
        <tr>
          <td>
            <!-- <a href='login.php' class="button">Login</a> -->
            <input type="button" class="button" value="Login">
            <a href='register.php' class="button">Register</a>
          </td>
        </tr>
        <tr>
          <td><h1>Log in</h1></td>
        </tr>

        <tr>
          <td><input type="email" name="email" placeholder="Username or email" class="style" required></td>
        </tr>

        <tr>
          <td><input type="password" name="password" class="style" placeholder="Passsword" required></td>
        </tr>

        <tr>
          <td><input type="submit" value="Login" name="Login" class="login"></td>
        </tr>
      </table>
    </form>
    <?php
      if (isset($_REQUEST['Login']))
      {
        include 'config.php';
    
        $email = mysqli_real_escape_string($conn,$_POST['email']);
        $password = md5($_POST['password']);
    
        $sql = "SELECT *FROM register WHERE email='{$email}' AND password='{$password}'";
        $res = mysqli_query($conn,$sql) or die("Query Failded");
        if (mysqli_num_rows($res)<=0)
        echo "<div id='warn'>Incorrect email or Password</div>";
        else
        {
          setcookie("email",$email, (time()+(60*60*24*10))); // save cookie 10 days
          setcookie("password",$password, (time()+(60*60*24*10))); // save cookie 10 days

          header("Location: http://localhost/PHP/University/home.php");
          mysqli_close($conn);
        }
      }
    ?>
  </div>
</div>
