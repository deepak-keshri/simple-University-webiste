<?php
  include 'config.php';
  $id = $_POST['id'];
  $fname = mysqli_real_escape_string($conn,$_POST['fname']);
  $lname = mysqli_real_escape_string($conn,$_POST['lname']);
  $username = mysqli_real_escape_string($conn,$_POST['user_name']);
  $father = mysqli_real_escape_string($conn,$_POST['father_name']);
  $mother = mysqli_real_escape_string($conn,$_POST['mother_name']);
  $course = mysqli_real_escape_string($conn,$_POST['course']);
  $gender = mysqli_real_escape_string($conn,$_POST['gender']);
  $adhar = mysqli_real_escape_string($conn,$_POST['adhar']);
  $mobile = mysqli_real_escape_string($conn,$_POST['mobile']);
  $religion = mysqli_real_escape_string($conn,$_POST['religion']);
  $nationality = mysqli_real_escape_string($conn,$_POST['nationality']);
  $address = mysqli_real_escape_string($conn,$_POST['address']);
  $pincode = mysqli_real_escape_string($conn,$_POST['pincode']);
  $password = md5($_POST['password']);
  $dob = mysqli_real_escape_string($conn,$_POST['dob']);

  $sql = "UPDATE stud_rec SET first_name='{$fname}',last_name='{$lname}',user_name='{$username}',father_name='{$father}',mother_name='{$mother}',course='{$course}',mobile='{$mobile}',gender='{$gender}',adhar='{$adhar}',religion='{$religion}',nationality='{$nationality}',address='{$address}',pincode='{$pincode}',password='{$password}',dob='{$dob}' WHERE id={$id}";
  echo $sql;
  mysqli_query($conn,$sql) or die("query Failed");
  echo $sql;

  header("Location: http://localhost/PHP/University/admin/all-record.php");
  mysqli_close($conn);  
?>