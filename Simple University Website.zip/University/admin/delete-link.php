<?php
  include 'config.php';
  $id = $_GET['id'];
  echo $id;

  $sql = "DELETE FROM stud_rec WHERE id={$id}";
  mysqli_query($conn,$sql) or die("Not Connected");
  
  header("Location: http://localhost/PHP/University/admin/all-record.php");
  mysqli_close($conn);
?>