<?php
    include 'config.php';
    session_start();
    if(isset($_SESSION["email"])){
      header("Location: http://localhost/PHP/University/admin/all-record.php");
    }
?>
<html>
  <head>
    <link rel="stylesheet" href="../style/style.css"></link>
  </head>
  <div id='login-id'>
    <div id='login'>
      <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        <table>
          <tr>
            <th id="sonbhadra">Sonbhadra University</th>
          </tr>
          <tr>
            <td><h1>Admin</h1></td>
          </tr>

          <tr>
            <td><input type="email" name="email" placeholder="Username or email" class="style" required></td>
          </tr>

          <tr>
            <td><input type="password" name="password" class="style" placeholder="Passsword" required></td>
          </tr>

          <tr>
            <td><input type="submit" value="Login" name="Login" class="login"></td>
          </tr>
        </table>
      </form>
      <?php
        if (isset($_REQUEST['Login']))
        {
          include 'config.php';
      
          $email = mysqli_real_escape_string($conn,$_POST['email']);
          $password = md5($_POST['password']);
      
          $sql = "SELECT admin_id, email, password FROM admin WHERE email='{$email}' AND password='{$password}'";
          $res = mysqli_query($conn,$sql) or die("Query Failded");
          
          if (mysqli_num_rows($res)>0)
          {
            while ($row = mysqli_fetch_assoc($res))
            {
              session_start();
              $_SESSION['user_id'] = $row['user_id'];
              $_SESSION['email'] = $row['email'];
              $_SESSION['password'] = $row['password'];

              header("Location: http://localhost/PHP/University/admin/all-record.php");
            }
          }
          else
          {
            echo "<div id='warn'>Invailid email or Password</div>";
          }
          /* mysqli_close($conn); */
        }
      ?>
    </div>
  </div>
</html>